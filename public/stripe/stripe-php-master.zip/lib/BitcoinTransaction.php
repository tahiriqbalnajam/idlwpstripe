<?php

namespace Stripe;

/**
 * Class BitcoinTransaction.
 */
class BitcoinTransaction extends ApiResource
{
    const OBJECT_NAME = 'bitcoin_transaction';
}
